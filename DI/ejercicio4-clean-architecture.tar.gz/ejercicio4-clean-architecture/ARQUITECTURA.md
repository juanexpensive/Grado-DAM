# Guía Detallada - Arquitectura y Patrones

## 🏛️ Clean Architecture

La aplicación sigue los principios de Clean Architecture de Robert C. Martin, separando el código en capas con dependencias unidireccionales:

```
Presentation → Domain ← Data
```

### Principios Aplicados

1. **Independencia de Frameworks**: El dominio no depende de React Native, MobX o Inversify
2. **Testeable**: La lógica de negocio se puede testear sin UI
3. **Independencia de UI**: Se puede cambiar la UI sin afectar al dominio
4. **Independencia de Base de Datos**: Se puede cambiar de API REST a GraphQL sin afectar al dominio

## 🎯 Capas de la Aplicación

### 1. Domain (Dominio)
**Responsabilidad**: Lógica de negocio pura, independiente de cualquier framework.

#### Entities (Entidades)
Objetos de negocio con identidad.
```typescript
class Persona {
  constructor(
    public id: number,
    public nombre: string,
    // ... otros campos
  ) {}
}
```

#### DTOs (Data Transfer Objects)
Objetos para transferir datos entre capas.
```typescript
class PersonaConNombreDeDepartamentoDTO {
  // Combina datos de Persona + Departamento para la UI
}
```

#### Interfaces
Contratos que deben cumplir las implementaciones.
- **Repositories**: Definen cómo acceder a los datos
- **Use Cases**: Definen las operaciones del negocio

#### Use Cases (Casos de Uso)
Implementan las reglas de negocio.

**Regla 1: Filtrado por edad en fin de semana**
```typescript
private aplicarReglaViernesSabado(personas: Persona[]): Persona[] {
  const diaSemana = new Date().getDay();
  if (diaSemana === 5 || diaSemana === 6) {
    return personas.filter(p => this.calcularEdad(p.fechaNacimiento) > 18);
  }
  return personas;
}
```

**Regla 2: No eliminar domingos**
```typescript
async eliminarPersona(id: number): Promise<number> {
  const diaSemana = new Date().getDay();
  if (diaSemana === 0) {
    throw new Error('No está permitido eliminar personas los domingos');
  }
  return await this.repositoryPersonas.eliminarPersona(id);
}
```

### 2. Data (Datos)
**Responsabilidad**: Acceso a fuentes de datos externas (API, base de datos, etc.)

#### Repositories
Implementan las interfaces definidas en Domain.

```typescript
@injectable()
export class PersonasRepositoryAPI implements IRepositoryPersonas {
  async getListaPersonas(): Promise<Persona[]> {
    const response = await fetch(this.apiUrl);
    const data = await response.json();
    
    // Mapeo de API (camelCase) a Entidad (domain)
    return data.map(item => new Persona(
      item.id,
      item.nombre,
      item.apellido,  // API usa singular
      item.fechaNac,  // API usa fechaNac
      // ...
    ));
  }
}
```

**Nota importante**: El repositorio mapea los datos de la API (que usa camelCase con nombres específicos) a las entidades del dominio.

### 3. Presentation (Presentación)
**Responsabilidad**: UI y lógica de presentación.

#### ViewModels (con MobX)
Gestionan el estado de la UI y coordinan las operaciones.

```typescript
export class PersonaViewModel {
  @observable personas: PersonaConNombreDeDepartamentoDTO[] = [];
  @observable isLoading: boolean = false;
  
  constructor(private useCasePersonas: IUseCasePersonas) {
    makeAutoObservable(this);
  }
  
  async cargarPersonas() {
    runInAction(() => {
      this.isLoading = true;
    });
    
    const personas = await this.useCasePersonas.getListaPersonasConDepartamento();
    
    runInAction(() => {
      this.personas = personas;
      this.isLoading = false;
    });
  }
}
```

#### Views
Componentes React que observan los ViewModels.

```typescript
export const ListadoPersonasView: React.FC = observer(() => {
  const { personaViewModel } = useViewModels();
  
  useEffect(() => {
    personaViewModel.cargarPersonas();
  }, []);
  
  return (
    // UI que se actualiza automáticamente cuando cambia el ViewModel
  );
});
```

## 🔌 Inyección de Dependencias con Inversify

### Container Configuration

```typescript
// src/core/container.ts
const container = new Container();

// Registrar implementaciones
container.bind<IRepositoryPersonas>(TYPES.IRepositoryPersonas)
  .to(PersonasRepositoryAPI);

container.bind<IUseCasePersonas>(TYPES.IUseCasePersonas)
  .to(DefaultUseCasePersonas);
```

### Inyección en Use Cases

```typescript
@injectable()
export class DefaultUseCasePersonas implements IUseCasePersonas {
  constructor(
    @inject(TYPES.IRepositoryPersonas) 
    private repositoryPersonas: IRepositoryPersonas,
    @inject(TYPES.IRepositoryDepartamentos) 
    private repositoryDepartamentos: IRepositoryDepartamentos
  ) {}
}
```

### Ventajas de DI

1. **Desacoplamiento**: Las clases no crean sus dependencias
2. **Testeable**: Se pueden inyectar mocks en tests
3. **Flexible**: Cambiar implementaciones sin modificar código
4. **Single Responsibility**: Cada clase hace solo una cosa

## 🎨 MVVM Pattern

```
View (React Component)
  ↓ observa
ViewModel (MobX)
  ↓ usa
Use Case
  ↓ usa
Repository
  ↓ accede a
API
```

### Flujo de Datos

1. **View** dispara una acción (ej: botón "Guardar")
2. **ViewModel** ejecuta el método correspondiente
3. **ViewModel** llama al **Use Case**
4. **Use Case** aplica reglas de negocio
5. **Use Case** llama al **Repository**
6. **Repository** hace la petición HTTP
7. **Repository** devuelve datos al **Use Case**
8. **Use Case** devuelve al **ViewModel**
9. **ViewModel** actualiza el estado (observables)
10. **View** se re-renderiza automáticamente (observer)

## 🔄 Flujo Completo de Ejemplo

### Crear una Persona

```typescript
// 1. Usuario presiona "Guardar" en EditarInsertarPersonasView
const handleGuardar = async () => {
  const persona = new Persona(...datos);
  
  // 2. View llama al ViewModel
  await personaViewModel.crearPersona(persona);
};

// 3. ViewModel (PersonaViewModel.ts)
async crearPersona(persona: Persona) {
  this.isLoading = true;
  
  // 4. ViewModel llama al Use Case
  await this.useCasePersonas.crearPersona(persona);
  
  // 5. Recarga la lista
  await this.cargarPersonas();
}

// 6. Use Case (DefaultUseCasePersonas.ts)
async crearPersona(persona: Persona): Promise<number> {
  // Aquí podrían aplicarse validaciones de negocio
  
  // 7. Use Case llama al Repository
  return await this.repositoryPersonas.crearPersona(persona);
}

// 8. Repository (PersonasRepositoryAPI.ts)
async crearPersona(personaNueva: Persona): Promise<number> {
  // 9. Repository hace la petición HTTP
  const response = await fetch(this.apiUrl, {
    method: 'POST',
    body: JSON.stringify({
      nombre: personaNueva.nombre,
      apellido: personaNueva.apellidos,  // Mapeo a formato API
      // ...
    }),
  });
  
  const data = await response.json();
  return data.id;
}
```

## 📊 DTOs vs Entidades

### ¿Cuándo usar cada uno?

**Entidades (Persona, Departamento)**
- Para crear/editar en la base de datos
- Representan objetos del dominio
- Se usan en repositories y use cases

**DTOs (PersonaConNombreDeDepartamentoDTO)**
- Para mostrar datos en la UI
- Combinan datos de múltiples entidades
- NO se usan para persistir datos

### Ejemplo Práctico

```typescript
// ❌ INCORRECTO - Editar un DTO
async actualizarPersona(dto: PersonaConNombreDeDepartamentoDTO) {
  // DTOs no tienen idDepartamento, solo nombreDepartamento
  // No se pueden guardar en la BD
}

// ✅ CORRECTO - Editar una Entidad
async actualizarPersona(id: number, persona: Persona) {
  // Persona tiene idDepartamento (número)
  // Se puede guardar en la BD
  await this.repositoryPersonas.actualizarPersona(id, persona);
}
```

### En la Vista de Edición

```typescript
// 1. Cargar datos (ViewModel obtiene Entidad, no DTO)
await personaViewModel.cargarPersonaPorId(personaId);
const persona = personaViewModel.personaSeleccionada; // Es Persona, no DTO

// 2. Mostrar en formulario
setNombre(persona.nombre);
setIdDepartamento(persona.idDepartamento); // Número, no nombre

// 3. Guardar (crear Entidad desde formulario)
const personaActualizada = new Persona(
  personaId,
  nombre,
  apellidos,
  // ...
  idDepartamento  // Número del Picker
);

await personaViewModel.actualizarPersona(personaId, personaActualizada);
```

## 🧪 Testing (Ejemplo de cómo testear)

### Test de Use Case

```typescript
describe('DefaultUseCasePersonas', () => {
  it('debe filtrar personas menores de 18 los viernes', async () => {
    // Arrange
    const mockRepo = {
      getListaPersonas: jest.fn().mockResolvedValue([
        new Persona(1, 'Juan', 'Pérez', '2010-01-01', ...),  // Menor
        new Persona(2, 'Ana', 'García', '1990-01-01', ...), // Mayor
      ])
    };
    
    const useCase = new DefaultUseCasePersonas(mockRepo, ...);
    
    // Act (asumiendo que es viernes)
    const personas = await useCase.getListaPersonas();
    
    // Assert
    expect(personas).toHaveLength(1);
    expect(personas[0].nombre).toBe('Ana');
  });
});
```

## 🎯 Mejores Prácticas Aplicadas

1. ✅ **Single Responsibility**: Cada clase tiene una única responsabilidad
2. ✅ **Dependency Inversion**: Las clases dependen de abstracciones (interfaces)
3. ✅ **Open/Closed**: Abierto a extensión, cerrado a modificación
4. ✅ **Don't Repeat Yourself**: Lógica compartida en use cases
5. ✅ **Separation of Concerns**: UI, lógica y datos separados

## 🔍 Debugging

### Ver qué está pasando en el ViewModel

```typescript
// En el ViewModel, agregar logs
async cargarPersonas() {
  console.log('Cargando personas...');
  runInAction(() => {
    this.isLoading = true;
  });
  
  const personas = await this.useCasePersonas.getListaPersonasConDepartamento();
  console.log('Personas cargadas:', personas.length);
  
  runInAction(() => {
    this.personas = personas;
    this.isLoading = false;
  });
}
```

### React DevTools

Usar React DevTools para inspeccionar el estado de los componentes y ver los valores de los observables.

## 📚 Recursos Adicionales

- [Clean Architecture - Robert C. Martin](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [MVVM Pattern](https://learn.microsoft.com/en-us/dotnet/architecture/maui/mvvm)
- [Inversify Documentation](https://inversify.io/)
- [MobX Documentation](https://mobx.js.org/)
