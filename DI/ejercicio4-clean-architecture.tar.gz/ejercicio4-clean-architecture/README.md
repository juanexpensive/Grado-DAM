# Ejercicio 4 - Clean Architecture con React Native

Aplicación de gestión de Personas y Departamentos siguiendo **Clean Architecture**, **MVVM**, **Inyección de Dependencias con Inversify** y **MobX** para los ViewModels.

## 🏗️ Arquitectura

### Capas de la Aplicación

```
src/
├── core/                       # Configuración de DI
│   ├── container.ts           # Contenedor de Inversify
│   └── types.ts               # Símbolos para DI
│
├── domain/                     # Capa de Dominio (Lógica de Negocio)
│   ├── entities/              # Entidades del dominio
│   │   ├── Departamento.ts
│   │   └── Persona.ts
│   ├── dtos/                  # Data Transfer Objects
│   │   └── PersonaConNombreDeDepartamentoDTO.ts
│   ├── interfaces/
│   │   ├── repositories/      # Contratos de repositorios
│   │   │   ├── IRepositoryDepartamentos.ts
│   │   │   └── IRepositoryPersonas.ts
│   │   └── use-cases/         # Contratos de casos de uso
│   │       ├── IUseCaseDepartamentos.ts
│   │       └── IUseCasePersonas.ts
│   └── use-cases/             # Implementación de casos de uso
│       ├── DefaultUseCaseDepartamentos.ts
│       └── DefaultUseCasePersonas.ts
│
├── data/                       # Capa de Datos
│   ├── db/
│   │   └── config.ts          # Configuración de API
│   └── repositories/          # Implementación de repositorios
│       ├── DepartamentosRepositoryAPI.ts
│       └── PersonasRepositoryAPI.ts
│
└── presentation/               # Capa de Presentación
    ├── context/               # Context de React para ViewModels
    │   └── ViewModelsContext.tsx
    ├── viewmodels/            # ViewModels con MobX
    │   ├── PersonaViewModel.ts
    │   └── DepartamentoViewModel.ts
    ├── views/                 # Vistas de la aplicación
    │   ├── BienvenidaView.tsx
    │   ├── ListadoPersonasView.tsx
    │   ├── EditarInsertarPersonasView.tsx
    │   ├── ListadoDepartamentosView.tsx
    │   └── EditarInsertarDepartamentoView.tsx
    └── navigation/            # Navegación
        └── AppNavigator.tsx
```

## 📋 Funcionalidades

### Personas
- ✅ Listado de personas con búsqueda
- ✅ Crear nueva persona
- ✅ Editar persona existente
- ✅ Eliminar persona
- ✅ Visualización de foto de persona
- ✅ Asociación con departamento

### Departamentos
- ✅ Listado de departamentos con búsqueda
- ✅ Crear nuevo departamento
- ✅ Editar departamento existente
- ✅ Eliminar departamento

### Reglas de Negocio Implementadas

1. **Filtrado por edad (Viernes y Sábado)**
   - Los viernes y sábados, solo se muestran personas mayores de 18 años

2. **Restricción de eliminación (Domingo)**
   - No se permite eliminar personas los domingos
   - El sistema muestra un error al intentarlo

## 🚀 Instalación

1. Instalar dependencias:
```bash
npm install
```

2. Configurar la URL de la API:
   - Editar el archivo `src/data/db/config.ts`
   - Reemplazar `BASE_URL` con la URL de tu API de Azure

```typescript
export const API_CONFIG = {
  BASE_URL: 'https://tu-api-azure.azurewebsites.net/api',
  // ...
};
```

3. Ejecutar la aplicación:
```bash
# Para desarrollo
npm start

# Para Android
npm run android

# Para iOS
npm run ios
```

## 🔌 Integración con API

La aplicación espera que la API devuelva los datos en formato camelCase:

### Persona (de la API)
```json
{
  "id": 10,
  "nombre": "Lidia",
  "apellido": "Jannaway",
  "fechaNac": "1960-10-10T00:00:00",
  "direccion": "47 Summit Pass",
  "telefono": "7484365412",
  "imagen": "https://i.pravatar.cc/500?img=36",
  "idDepartamento": 28
}
```

### Departamento (de la API)
```json
{
  "id": 1,
  "nombre": "Recursos Humanos"
}
```

## 🎨 Características de la UI

- **Drawer Navigation** para navegar entre secciones
- **Búsqueda en tiempo real** en listados
- **Cards visuales** para mostrar información
- **Botón flotante (+)** para crear nuevos registros
- **Confirmaciones** antes de eliminar
- **Indicadores de carga** durante operaciones
- **Manejo de errores** con alertas visuales

## 📱 Vistas de la Aplicación

### 1. Bienvenida
Pantalla inicial con información de la aplicación.

### 2. Listado de Personas
- Muestra todas las personas con sus datos
- Foto, nombre, departamento, teléfono y dirección
- Búsqueda por nombre, apellidos o departamento
- Botones para editar y eliminar

### 3. Editar/Insertar Persona
- Formulario completo con validaciones
- Selección de departamento mediante Picker
- Preview de foto
- Maneja tanto creación como edición

### 4. Listado de Departamentos
- Lista de todos los departamentos
- Búsqueda por nombre
- Botones para editar y eliminar

### 5. Editar/Insertar Departamento
- Formulario simple para nombre del departamento
- Maneja tanto creación como edición

## 🔧 Tecnologías Utilizadas

- **React Native** + **Expo**
- **TypeScript**
- **Inversify** (Inyección de Dependencias)
- **MobX** (Estado reactivo en ViewModels)
- **React Navigation** (Drawer + Stack)
- **Clean Architecture**
- **MVVM Pattern**

## 📝 Notas Importantes

1. **DTOs vs Entidades**: 
   - Los DTOs se usan solo para mostrar datos en las vistas (ej: persona con nombre de departamento)
   - Las entidades se usan para crear/editar en la base de datos
   - Nunca se edita un DTO directamente

2. **IDs ocultos**:
   - Los IDs no se muestran ni se pueden modificar en las vistas
   - La API gestiona automáticamente los IDs al crear registros

3. **Mapeo de campos**:
   - La API usa `apellido` (singular) → la app usa `apellidos` (plural)
   - La API usa `fechaNac` → la app usa `fechaNacimiento`
   - La API usa `imagen` → la app usa `foto`

## 🎯 Próximas Mejoras

- [ ] Implementar subida de fotos a Azure Storage
- [ ] Añadir validación de formato de fecha más robusta
- [ ] Implementar paginación en listados
- [ ] Añadir filtros avanzados
- [ ] Implementar caché local de datos
- [ ] Añadir modo offline

## 👨‍💻 Autor

Ejercicio 4 - Clean Architecture
