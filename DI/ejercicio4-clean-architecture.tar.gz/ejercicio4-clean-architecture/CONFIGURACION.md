# Guía de Configuración y Troubleshooting

## 🔧 Configuración Inicial

### 1. Configurar la URL de la API

Edita el archivo `src/data/db/config.ts`:

```typescript
export const API_CONFIG = {
  BASE_URL: 'https://tu-api-azure.azurewebsites.net/api',
  ENDPOINTS: {
    PERSONAS: '/personas',
    DEPARTAMENTOS: '/departamentos',
  },
};
```

**Ejemplos de URLs completas:**
- Listar personas: `https://tu-api-azure.azurewebsites.net/api/personas`
- Obtener persona: `https://tu-api-azure.azurewebsites.net/api/personas/10`
- Crear persona: `POST https://tu-api-azure.azurewebsites.net/api/personas`

### 2. Verificar el Formato de la API

La aplicación espera que la API devuelva datos en este formato:

#### Persona (GET /personas o GET /personas/10)
```json
{
  "id": 10,
  "nombre": "Lidia",
  "apellido": "Jannaway",
  "fechaNac": "1960-10-10T00:00:00",
  "direccion": "47 Summit Pass",
  "telefono": "7484365412",
  "imagen": "https://i.pravatar.cc/500?img=36",
  "idDepartamento": 28
}
```

#### Departamento (GET /departamentos o GET /departamentos/1)
```json
{
  "id": 1,
  "nombre": "Recursos Humanos"
}
```

### 3. Endpoints que debe soportar la API

#### Personas
- `GET /api/personas` - Listar todas las personas
- `GET /api/personas/{id}` - Obtener una persona
- `POST /api/personas` - Crear persona
- `PUT /api/personas/{id}` - Actualizar persona
- `DELETE /api/personas/{id}` - Eliminar persona

#### Departamentos
- `GET /api/departamentos` - Listar todos los departamentos
- `GET /api/departamentos/{id}` - Obtener un departamento
- `POST /api/departamentos` - Crear departamento
- `PUT /api/departamentos/{id}` - Actualizar departamento
- `DELETE /api/departamentos/{id}` - Eliminar departamento

### 4. Ejemplo de Peticiones HTTP

#### Crear Persona (POST)
```json
{
  "nombre": "Juan",
  "apellido": "Pérez",
  "fechaNac": "1990-05-15T00:00:00",
  "direccion": "Calle Principal 123",
  "telefono": "123456789",
  "imagen": "https://i.pravatar.cc/500?img=1",
  "idDepartamento": 5
}
```

#### Actualizar Persona (PUT)
```json
{
  "id": 10,
  "nombre": "Juan Actualizado",
  "apellido": "Pérez",
  "fechaNac": "1990-05-15T00:00:00",
  "direccion": "Nueva Dirección 456",
  "telefono": "987654321",
  "imagen": "https://i.pravatar.cc/500?img=1",
  "idDepartamento": 7
}
```

#### Crear Departamento (POST)
```json
{
  "nombre": "Marketing"
}
```

## 🐛 Troubleshooting

### Error: "Network request failed"

**Causas posibles:**
1. La URL de la API está mal configurada
2. La API no está accesible
3. Problemas de CORS (si usas web)

**Soluciones:**
```typescript
// 1. Verificar la URL en config.ts
console.log(API_CONFIG.BASE_URL); // Debe ser una URL válida

// 2. Probar la API manualmente
// Abre el navegador y ve a:
// https://tu-api-azure.azurewebsites.net/api/personas

// 3. Para desarrollo local, puedes usar:
export const API_CONFIG = {
  BASE_URL: 'http://localhost:5000/api', // Puerto de tu API local
  // ...
};
```

### Error: "Cannot read property 'nombre' of undefined"

**Causa:** La API devuelve los datos en un formato diferente al esperado.

**Solución:** Verificar el mapeo en los repositorios.

```typescript
// En PersonasRepositoryAPI.ts
async getListaPersonas(): Promise<Persona[]> {
  const data = await response.json();
  
  // Si la API devuelve { personas: [...] } en lugar de [...]
  // Ajustar a:
  const personas = data.personas || data;
  
  return personas.map((item: any) => new Persona(
    item.id,
    item.nombre,
    item.apellido,  // Verificar nombre exacto del campo
    // ...
  ));
}
```

### Error: "No se puede eliminar personas los domingos"

**Causa:** Es domingo y la regla de negocio lo impide.

**Solución:** 
- Esperar a otro día, o
- Para testing, comentar temporalmente la validación en `DefaultUseCasePersonas.ts`:

```typescript
async eliminarPersona(id: number): Promise<number> {
  // const hoy = new Date();
  // const diaSemana = hoy.getDay();
  // if (diaSemana === 0) {
  //   throw new Error('No está permitido eliminar personas los domingos');
  // }
  
  return await this.repositoryPersonas.eliminarPersona(id);
}
```

### Solo aparecen personas mayores de 18

**Causa:** Es viernes o sábado y la regla de negocio filtra menores de edad.

**Verificación:**
```typescript
// En DefaultUseCasePersonas.ts
private aplicarReglaViernesSabado(personas: Persona[]): Persona[] {
  const hoy = new Date();
  const diaSemana = hoy.getDay();
  
  console.log('Día de la semana:', diaSemana); // 5=Viernes, 6=Sábado
  console.log('Total personas:', personas.length);
  
  // ... resto del código
}
```

### Error: "Debe seleccionar un departamento"

**Causa:** El Picker de departamentos no tiene un valor seleccionado.

**Solución:** Asegurarse de que el estado `idDepartamento` se inicializa correctamente:

```typescript
// En EditarInsertarPersonasView.tsx
const [idDepartamento, setIdDepartamento] = useState<number>(0);

// Si es edición, debe cargarse el valor:
const cargarDatosPersona = async () => {
  const persona = personaViewModel.personaSeleccionada;
  if (persona) {
    setIdDepartamento(persona.idDepartamento); // ✅ Esto es importante
  }
};
```

### Las imágenes no se muestran

**Causas posibles:**
1. La URL de la imagen no es válida
2. Problemas de CORS
3. La imagen requiere autenticación

**Soluciones:**
```typescript
// 1. Verificar que la URL sea válida
console.log('URL de imagen:', persona.foto);

// 2. Agregar defaultSource en Image
<Image 
  source={{ uri: item.foto }} 
  defaultSource={require('../../../assets/default-avatar.png')}
  onError={() => console.log('Error cargando imagen')}
/>

// 3. Usar un servicio de imágenes público
// Ejemplo: https://i.pravatar.cc/500?img=36
```

### Error: "reflect-metadata" must be imported before

**Causa:** No se importó reflect-metadata al inicio.

**Solución:** Asegurarse de que `App.tsx` comience con:
```typescript
import 'reflect-metadata';
import React from 'react';
// ... resto de imports
```

### Error con decoradores en TypeScript

**Causa:** Los decoradores no están habilitados correctamente.

**Solución:** Verificar `tsconfig.json`:
```json
{
  "compilerOptions": {
    "experimentalDecorators": true,
    "emitDecoratorMetadata": true,
    // ...
  }
}
```

Y verificar `babel.config.js`:
```javascript
plugins: [
  ['@babel/plugin-proposal-decorators', { legacy: true }],
  // ...
]
```

### Los cambios no se reflejan en la UI

**Causa:** El componente no está observando el ViewModel.

**Solución:** Verificar que el componente use `observer`:
```typescript
// ❌ INCORRECTO
export const MiComponente: React.FC = () => {

// ✅ CORRECTO
export const MiComponente: React.FC = observer(() => {
```

### Error: "Cannot find module @react-native-picker/picker"

**Solución:**
```bash
npm install @react-native-picker/picker
```

## 📱 Testing Manual

### 1. Probar Creación de Persona

1. Ir a "Listado de Personas"
2. Presionar el botón flotante "+"
3. Llenar todos los campos
4. Seleccionar un departamento
5. Presionar "Crear"
6. Verificar que aparece en el listado

### 2. Probar Edición de Persona

1. En el listado, presionar "Editar" en una persona
2. Modificar algún campo
3. Presionar "Actualizar"
4. Verificar que los cambios se guardaron

### 3. Probar Búsqueda

1. En el listado, escribir en el campo de búsqueda
2. Verificar que filtra en tiempo real
3. Buscar por nombre, apellido o departamento

### 4. Probar Eliminación

1. Presionar "Eliminar" en una persona (no en domingo)
2. Confirmar la eliminación
3. Verificar que desaparece del listado

### 5. Probar Regla de Negocio - Domingo

1. Cambiar la fecha del dispositivo a domingo
2. Intentar eliminar una persona
3. Verificar que muestra el error

### 6. Probar Regla de Negocio - Viernes/Sábado

1. Cambiar la fecha del dispositivo a viernes o sábado
2. Verificar que solo aparecen personas mayores de 18 años

## 🔍 Debugging Avanzado

### Ver todas las peticiones HTTP

Agregar logs en los repositorios:

```typescript
async getListaPersonas(): Promise<Persona[]> {
  console.log('→ GET', this.apiUrl);
  const response = await fetch(this.apiUrl);
  console.log('← Status:', response.status);
  const data = await response.json();
  console.log('← Data:', data);
  return data.map(/* ... */);
}
```

### Ver el flujo completo de datos

```typescript
// En UseCase
console.log('UseCase: getListaPersonasConDepartamento');

// En ViewModel
console.log('ViewModel: cargarPersonas - inicio');
console.log('ViewModel: cargarPersonas - fin', personas.length);

// En View
console.log('View: useEffect ejecutado');
```

## 📋 Checklist de Configuración

- [ ] URL de API configurada en `config.ts`
- [ ] API accesible desde el navegador
- [ ] Formato de datos de API verificado
- [ ] Dependencias instaladas (`npm install`)
- [ ] `reflect-metadata` importado en `App.tsx`
- [ ] Babel configurado con decoradores
- [ ] TypeScript configurado con `experimentalDecorators`

## 🚀 Comandos Útiles

```bash
# Limpiar caché
npm start -- --clear

# Reinstalar dependencias
rm -rf node_modules package-lock.json
npm install

# Ver logs detallados
npx react-native log-android
npx react-native log-ios

# Ejecutar en dispositivo físico
npm run android -- --deviceId=DEVICE_ID
```

## 📞 Soporte

Si encuentras problemas no listados aquí:

1. Revisa los logs en la consola
2. Verifica que la API funcione con Postman
3. Comprueba que los datos estén en el formato esperado
4. Revisa que las dependencias estén instaladas correctamente
