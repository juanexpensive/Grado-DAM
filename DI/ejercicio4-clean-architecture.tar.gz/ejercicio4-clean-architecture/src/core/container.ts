import 'reflect-metadata';
import { Container } from 'inversify';
import { TYPES } from './types';

// Interfaces
import { IRepositoryDepartamentos } from '../domain/interfaces/repositories/IRepositoryDepartamentos';
import { IRepositoryPersonas } from '../domain/interfaces/repositories/IRepositoryPersonas';
import { IUseCaseDepartamentos } from '../domain/interfaces/use-cases/IUseCaseDepartamentos';
import { IUseCasePersonas } from '../domain/interfaces/use-cases/IUseCasePersonas';

// Implementaciones
import { DepartamentosRepositoryAPI } from '../data/repositories/DepartamentosRepositoryAPI';
import { PersonasRepositoryAPI } from '../data/repositories/PersonasRepositoryAPI';
import { DefaultUseCaseDepartamentos } from '../domain/use-cases/DefaultUseCaseDepartamentos';
import { DefaultUseCasePersonas } from '../domain/use-cases/DefaultUseCasePersonas';

const container = new Container();

// Bind Repositories
container.bind<IRepositoryDepartamentos>(TYPES.IRepositoryDepartamentos).to(DepartamentosRepositoryAPI);
container.bind<IRepositoryPersonas>(TYPES.IRepositoryPersonas).to(PersonasRepositoryAPI);

// Bind Use Cases
container.bind<IUseCaseDepartamentos>(TYPES.IUseCaseDepartamentos).to(DefaultUseCaseDepartamentos);
container.bind<IUseCasePersonas>(TYPES.IUseCasePersonas).to(DefaultUseCasePersonas);

export { container };
