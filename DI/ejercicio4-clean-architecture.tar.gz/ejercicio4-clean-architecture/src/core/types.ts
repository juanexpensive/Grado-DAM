export const TYPES = {
  IRepositoryDepartamentos: Symbol.for('IRepositoryDepartamentos'),
  IRepositoryPersonas: Symbol.for('IRepositoryPersonas'),
  IUseCaseDepartamentos: Symbol.for('IUseCaseDepartamentos'),
  IUseCasePersonas: Symbol.for('IUseCasePersonas'),
};
