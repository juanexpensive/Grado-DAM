export class PersonaConNombreDeDepartamentoDTO {
  constructor(
    public id: number,
    public nombre: string,
    public apellidos: string,
    public fechaNacimiento: string,
    public direccion: string,
    public telefono: string,
    public foto: string,
    public nombreDepartamento: string
  ) {}
}
