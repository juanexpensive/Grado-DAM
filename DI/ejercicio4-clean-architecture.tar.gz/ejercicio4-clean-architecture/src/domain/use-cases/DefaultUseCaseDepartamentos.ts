import { injectable, inject } from 'inversify';
import { IUseCaseDepartamentos } from '../interfaces/use-cases/IUseCaseDepartamentos';
import { IRepositoryDepartamentos } from '../interfaces/repositories/IRepositoryDepartamentos';
import { IRepositoryPersonas } from '../interfaces/repositories/IRepositoryPersonas';
import { Departamento } from '../entities/Departamento';
import { Persona } from '../entities/Persona';
import { TYPES } from '../../core/types';

@injectable()
export class DefaultUseCaseDepartamentos implements IUseCaseDepartamentos {
  constructor(
    @inject(TYPES.IRepositoryDepartamentos) private repositoryDepartamentos: IRepositoryDepartamentos,
    @inject(TYPES.IRepositoryPersonas) private repositoryPersonas: IRepositoryPersonas
  ) {}

  async getDepartamentos(): Promise<Departamento[]> {
    return await this.repositoryDepartamentos.getListaDepartamentos();
  }

  async getDetalleDepartamento(id: number): Promise<Departamento | null> {
    return await this.repositoryDepartamentos.getDepartamentoById(id);
  }

  async getPersonasPorDepartamento(id: number): Promise<Persona[]> {
    const todasLasPersonas = await this.repositoryPersonas.getListaPersonas();
    return todasLasPersonas.filter(persona => persona.idDepartamento === id);
  }

  async crearDepartamento(departamento: Departamento): Promise<void> {
    await this.repositoryDepartamentos.crearDepartamento(departamento);
  }

  async actualizarDepartamento(departamento: Departamento): Promise<void> {
    await this.repositoryDepartamentos.actualizarDepartamento(departamento.id, departamento);
  }

  async eliminarDepartamento(id: number): Promise<void> {
    await this.repositoryDepartamentos.eliminarDepartamento(id);
  }
}
