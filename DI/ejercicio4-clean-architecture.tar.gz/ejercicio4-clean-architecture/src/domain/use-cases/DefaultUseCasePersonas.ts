import { injectable, inject } from 'inversify';
import { IUseCasePersonas } from '../interfaces/use-cases/IUseCasePersonas';
import { IRepositoryPersonas } from '../interfaces/repositories/IRepositoryPersonas';
import { IRepositoryDepartamentos } from '../interfaces/repositories/IRepositoryDepartamentos';
import { Persona } from '../entities/Persona';
import { PersonaConNombreDeDepartamentoDTO } from '../dtos/PersonaConNombreDeDepartamentoDTO';
import { TYPES } from '../../core/types';

@injectable()
export class DefaultUseCasePersonas implements IUseCasePersonas {
  constructor(
    @inject(TYPES.IRepositoryPersonas) private repositoryPersonas: IRepositoryPersonas,
    @inject(TYPES.IRepositoryDepartamentos) private repositoryDepartamentos: IRepositoryDepartamentos
  ) {}

  private calcularEdad(fechaNacimiento: string): number {
    const hoy = new Date();
    const nacimiento = new Date(fechaNacimiento);
    let edad = hoy.getFullYear() - nacimiento.getFullYear();
    const mes = hoy.getMonth() - nacimiento.getMonth();
    
    if (mes < 0 || (mes === 0 && hoy.getDate() < nacimiento.getDate())) {
      edad--;
    }
    
    return edad;
  }

  private aplicarReglaViernesSabado(personas: Persona[]): Persona[] {
    const hoy = new Date();
    const diaSemana = hoy.getDay(); // 0 = Domingo, 5 = Viernes, 6 = Sábado
    
    // Si es viernes (5) o sábado (6), filtrar solo mayores de 18
    if (diaSemana === 5 || diaSemana === 6) {
      return personas.filter(persona => this.calcularEdad(persona.fechaNacimiento) > 18);
    }
    
    return personas;
  }

  async getListaPersonasConDepartamento(): Promise<PersonaConNombreDeDepartamentoDTO[]> {
    const personas = await this.repositoryPersonas.getListaPersonas();
    const personasFiltradas = this.aplicarReglaViernesSabado(personas);
    const departamentos = await this.repositoryDepartamentos.getListaDepartamentos();
    
    return personasFiltradas.map(persona => {
      const departamento = departamentos.find(d => d.id === persona.idDepartamento);
      return new PersonaConNombreDeDepartamentoDTO(
        persona.id,
        persona.nombre,
        persona.apellidos,
        persona.fechaNacimiento,
        persona.direccion,
        persona.telefono,
        persona.foto,
        departamento?.nombre || 'Sin departamento'
      );
    });
  }

  async getListaPersonas(): Promise<Persona[]> {
    const personas = await this.repositoryPersonas.getListaPersonas();
    return this.aplicarReglaViernesSabado(personas);
  }

  async getDetallePersona(id: number): Promise<PersonaConNombreDeDepartamentoDTO | null> {
    const persona = await this.repositoryPersonas.getPersonaById(id);
    if (!persona) return null;
    
    const departamento = await this.repositoryDepartamentos.getDepartamentoById(persona.idDepartamento);
    
    return new PersonaConNombreDeDepartamentoDTO(
      persona.id,
      persona.nombre,
      persona.apellidos,
      persona.fechaNacimiento,
      persona.direccion,
      persona.telefono,
      persona.foto,
      departamento?.nombre || 'Sin departamento'
    );
  }

  async crearPersona(persona: Persona): Promise<number> {
    return await this.repositoryPersonas.crearPersona(persona);
  }

  async actualizarPersona(id: number, persona: Persona): Promise<number> {
    return await this.repositoryPersonas.actualizarPersona(id, persona);
  }

  async eliminarPersona(id: number): Promise<number> {
    const hoy = new Date();
    const diaSemana = hoy.getDay();
    
    // Regla de negocio: No se puede eliminar personas los domingos (día 0)
    if (diaSemana === 0) {
      throw new Error('No está permitido eliminar personas los domingos');
    }
    
    return await this.repositoryPersonas.eliminarPersona(id);
  }
}
