import { Persona } from '../entities/Persona';

export interface IRepositoryPersonas {
  getListaPersonas(): Promise<Persona[]>;
  getPersonaById(idPersona: number): Promise<Persona | null>;
  crearPersona(personaNueva: Persona): Promise<number>;
  actualizarPersona(idPersona: number, persona: Persona): Promise<number>;
  eliminarPersona(idPersona: number): Promise<number>;
  contarPersonaDepartamento(idDepartamento: number): Promise<number>;
}
