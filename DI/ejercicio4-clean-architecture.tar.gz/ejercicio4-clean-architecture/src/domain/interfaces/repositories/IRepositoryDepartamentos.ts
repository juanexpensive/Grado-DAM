import { Departamento } from '../entities/Departamento';

export interface IRepositoryDepartamentos {
  getListaDepartamentos(): Promise<Departamento[]>;
  getDepartamentoById(idDepartamento: number): Promise<Departamento | null>;
  crearDepartamento(departamentoNuevo: Departamento): Promise<number>;
  actualizarDepartamento(idDepartamento: number, departamento: Departamento): Promise<number>;
  eliminarDepartamento(idDepartamento: number): Promise<number>;
}
