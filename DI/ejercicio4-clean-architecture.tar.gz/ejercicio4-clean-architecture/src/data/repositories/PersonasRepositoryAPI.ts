import { injectable } from 'inversify';
import { IRepositoryPersonas } from '../../domain/interfaces/repositories/IRepositoryPersonas';
import { Persona } from '../../domain/entities/Persona';
import { API_CONFIG } from '../db/config';

@injectable()
export class PersonasRepositoryAPI implements IRepositoryPersonas {
  private apiUrl = `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.PERSONAS}`;

  async getListaPersonas(): Promise<Persona[]> {
    try {
      const response = await fetch(this.apiUrl);
      if (!response.ok) {
        throw new Error('Error al obtener personas');
      }
      const data = await response.json();
      
      // Mapear respuesta de API a entidad Persona
      // La API usa camelCase: id, nombre, apellido, fechaNac, direccion, telefono, imagen, idDepartamento
      return data.map((item: any) => new Persona(
        item.id,
        item.nombre,
        item.apellido, // API usa "apellido" singular
        item.fechaNac, // API usa "fechaNac"
        item.direccion,
        item.telefono,
        item.imagen, // API usa "imagen"
        item.idDepartamento
      ));
    } catch (error) {
      console.error('Error en getListaPersonas:', error);
      throw error;
    }
  }

  async getPersonaById(idPersona: number): Promise<Persona | null> {
    try {
      const response = await fetch(`${this.apiUrl}/${idPersona}`);
      if (!response.ok) {
        if (response.status === 404) return null;
        throw new Error('Error al obtener persona');
      }
      const data = await response.json();
      
      return new Persona(
        data.id,
        data.nombre,
        data.apellido,
        data.fechaNac,
        data.direccion,
        data.telefono,
        data.imagen,
        data.idDepartamento
      );
    } catch (error) {
      console.error('Error en getPersonaById:', error);
      throw error;
    }
  }

  async crearPersona(personaNueva: Persona): Promise<number> {
    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre: personaNueva.nombre,
          apellido: personaNueva.apellidos,
          fechaNac: personaNueva.fechaNacimiento,
          direccion: personaNueva.direccion,
          telefono: personaNueva.telefono,
          imagen: personaNueva.foto,
          idDepartamento: personaNueva.idDepartamento,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Error al crear persona');
      }
      
      const data = await response.json();
      return data.id || data;
    } catch (error) {
      console.error('Error en crearPersona:', error);
      throw error;
    }
  }

  async actualizarPersona(idPersona: number, persona: Persona): Promise<number> {
    try {
      const response = await fetch(`${this.apiUrl}/${idPersona}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: idPersona,
          nombre: persona.nombre,
          apellido: persona.apellidos,
          fechaNac: persona.fechaNacimiento,
          direccion: persona.direccion,
          telefono: persona.telefono,
          imagen: persona.foto,
          idDepartamento: persona.idDepartamento,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Error al actualizar persona');
      }
      
      return idPersona;
    } catch (error) {
      console.error('Error en actualizarPersona:', error);
      throw error;
    }
  }

  async eliminarPersona(idPersona: number): Promise<number> {
    try {
      const response = await fetch(`${this.apiUrl}/${idPersona}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Error al eliminar persona');
      }
      
      return idPersona;
    } catch (error) {
      console.error('Error en eliminarPersona:', error);
      throw error;
    }
  }

  async contarPersonaDepartamento(idDepartamento: number): Promise<number> {
    try {
      const personas = await this.getListaPersonas();
      return personas.filter(p => p.idDepartamento === idDepartamento).length;
    } catch (error) {
      console.error('Error en contarPersonaDepartamento:', error);
      throw error;
    }
  }
}
