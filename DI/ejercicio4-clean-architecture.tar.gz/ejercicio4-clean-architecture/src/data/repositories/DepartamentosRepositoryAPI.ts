import { injectable } from 'inversify';
import { IRepositoryDepartamentos } from '../../domain/interfaces/repositories/IRepositoryDepartamentos';
import { Departamento } from '../../domain/entities/Departamento';
import { API_CONFIG } from '../db/config';

@injectable()
export class DepartamentosRepositoryAPI implements IRepositoryDepartamentos {
  private apiUrl = `${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.DEPARTAMENTOS}`;

  async getListaDepartamentos(): Promise<Departamento[]> {
    try {
      const response = await fetch(this.apiUrl);
      if (!response.ok) {
        throw new Error('Error al obtener departamentos');
      }
      const data = await response.json();
      
      // Mapear respuesta de API a entidad Departamento
      return data.map((item: any) => new Departamento(
        item.id,
        item.nombre
      ));
    } catch (error) {
      console.error('Error en getListaDepartamentos:', error);
      throw error;
    }
  }

  async getDepartamentoById(idDepartamento: number): Promise<Departamento | null> {
    try {
      const response = await fetch(`${this.apiUrl}/${idDepartamento}`);
      if (!response.ok) {
        if (response.status === 404) return null;
        throw new Error('Error al obtener departamento');
      }
      const data = await response.json();
      
      return new Departamento(data.id, data.nombre);
    } catch (error) {
      console.error('Error en getDepartamentoById:', error);
      throw error;
    }
  }

  async crearDepartamento(departamentoNuevo: Departamento): Promise<number> {
    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nombre: departamentoNuevo.nombre,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Error al crear departamento');
      }
      
      const data = await response.json();
      return data.id || data;
    } catch (error) {
      console.error('Error en crearDepartamento:', error);
      throw error;
    }
  }

  async actualizarDepartamento(idDepartamento: number, departamento: Departamento): Promise<number> {
    try {
      const response = await fetch(`${this.apiUrl}/${idDepartamento}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: idDepartamento,
          nombre: departamento.nombre,
        }),
      });
      
      if (!response.ok) {
        throw new Error('Error al actualizar departamento');
      }
      
      return idDepartamento;
    } catch (error) {
      console.error('Error en actualizarDepartamento:', error);
      throw error;
    }
  }

  async eliminarDepartamento(idDepartamento: number): Promise<number> {
    try {
      const response = await fetch(`${this.apiUrl}/${idDepartamento}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        throw new Error('Error al eliminar departamento');
      }
      
      return idDepartamento;
    } catch (error) {
      console.error('Error en eliminarDepartamento:', error);
      throw error;
    }
  }
}
