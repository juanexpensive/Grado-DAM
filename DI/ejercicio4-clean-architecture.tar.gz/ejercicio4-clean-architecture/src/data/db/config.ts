export const API_CONFIG = {
  BASE_URL: 'https://tu-api-azure.azurewebsites.net/api', // Reemplazar con la URL real de tu API
  ENDPOINTS: {
    PERSONAS: '/personas',
    DEPARTAMENTOS: '/departamentos',
  },
};
