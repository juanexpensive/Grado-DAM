import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation, DrawerActions } from '@react-navigation/native';

export const BienvenidaView: React.FC = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
          style={styles.menuButton}
        >
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Text style={styles.title}>Bienvenido a la App</Text>
        <Text style={styles.subtitle}>Gestión de Personas y Departamentos</Text>
        
        <View style={styles.infoContainer}>
          <Text style={styles.infoText}>
            Esta aplicación te permite gestionar personas y departamentos de forma eficiente.
          </Text>
          
          <Text style={styles.infoText}>
            Usa el menú lateral para navegar entre las diferentes secciones:
          </Text>
          
          <View style={styles.listContainer}>
            <Text style={styles.listItem}>• Listado de Personas</Text>
            <Text style={styles.listItem}>• Listado de Departamentos</Text>
          </View>
          
          <Text style={styles.infoText}>
            Podrás crear, editar, buscar y eliminar tanto personas como departamentos.
          </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuButton: {
    padding: 5,
  },
  menuIcon: {
    fontSize: 24,
    color: '#fff',
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2196F3',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
  },
  infoContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoText: {
    fontSize: 16,
    color: '#333',
    marginBottom: 15,
    lineHeight: 24,
  },
  listContainer: {
    marginLeft: 20,
    marginBottom: 15,
  },
  listItem: {
    fontSize: 16,
    color: '#555',
    marginBottom: 8,
  },
});
