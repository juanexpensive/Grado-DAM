import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, Alert, Image } from 'react-native';
import { observer } from 'mobx-react-lite';
import { useViewModels } from '../context/ViewModelsContext';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Persona } from '../../domain/entities/Persona';
import { Picker } from '@react-native-picker/picker';

export const EditarInsertarPersonasView: React.FC = observer(() => {
  const { personaViewModel, departamentoViewModel } = useViewModels();
  const navigation = useNavigation();
  const route = useRoute<any>();
  
  const personaId = route.params?.personaId;
  const isEditing = !!personaId;

  const [nombre, setNombre] = useState('');
  const [apellidos, setApellidos] = useState('');
  const [fechaNacimiento, setFechaNacimiento] = useState('');
  const [direccion, setDireccion] = useState('');
  const [telefono, setTelefono] = useState('');
  const [foto, setFoto] = useState('');
  const [idDepartamento, setIdDepartamento] = useState<number>(0);

  useEffect(() => {
    departamentoViewModel.cargarDepartamentos();
    
    if (isEditing) {
      cargarDatosPersona();
    }
  }, []);

  const cargarDatosPersona = async () => {
    await personaViewModel.cargarPersonaPorId(personaId);
    const persona = personaViewModel.personaSeleccionada;
    
    if (persona) {
      setNombre(persona.nombre);
      setApellidos(persona.apellidos);
      setFechaNacimiento(persona.fechaNacimiento.split('T')[0]); // Formato YYYY-MM-DD
      setDireccion(persona.direccion);
      setTelefono(persona.telefono);
      setFoto(persona.foto);
      setIdDepartamento(persona.idDepartamento);
    }
  };

  const validarCampos = (): boolean => {
    if (!nombre.trim()) {
      Alert.alert('Error', 'El nombre es obligatorio');
      return false;
    }
    if (!apellidos.trim()) {
      Alert.alert('Error', 'Los apellidos son obligatorios');
      return false;
    }
    if (!fechaNacimiento.trim()) {
      Alert.alert('Error', 'La fecha de nacimiento es obligatoria');
      return false;
    }
    if (!idDepartamento || idDepartamento === 0) {
      Alert.alert('Error', 'Debe seleccionar un departamento');
      return false;
    }
    return true;
  };

  const handleGuardar = async () => {
    if (!validarCampos()) return;

    const persona = new Persona(
      isEditing ? personaId : 0,
      nombre,
      apellidos,
      fechaNacimiento,
      direccion,
      telefono,
      foto || 'https://i.pravatar.cc/500',
      idDepartamento
    );

    try {
      if (isEditing) {
        await personaViewModel.actualizarPersona(personaId, persona);
        Alert.alert('Éxito', 'Persona actualizada correctamente');
      } else {
        await personaViewModel.crearPersona(persona);
        Alert.alert('Éxito', 'Persona creada correctamente');
      }
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', personaViewModel.error || 'No se pudo guardar la persona');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>← Volver</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {isEditing ? 'Editar Persona' : 'Nueva Persona'}
        </Text>
      </View>

      <ScrollView style={styles.content}>
        {foto ? (
          <Image source={{ uri: foto }} style={styles.previewImage} />
        ) : null}

        <View style={styles.formGroup}>
          <Text style={styles.label}>Nombre *</Text>
          <TextInput
            style={styles.input}
            value={nombre}
            onChangeText={setNombre}
            placeholder="Ingrese el nombre"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Apellidos *</Text>
          <TextInput
            style={styles.input}
            value={apellidos}
            onChangeText={setApellidos}
            placeholder="Ingrese los apellidos"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Fecha de Nacimiento * (YYYY-MM-DD)</Text>
          <TextInput
            style={styles.input}
            value={fechaNacimiento}
            onChangeText={setFechaNacimiento}
            placeholder="2000-01-01"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Dirección</Text>
          <TextInput
            style={styles.input}
            value={direccion}
            onChangeText={setDireccion}
            placeholder="Ingrese la dirección"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Teléfono</Text>
          <TextInput
            style={styles.input}
            value={telefono}
            onChangeText={setTelefono}
            placeholder="Ingrese el teléfono"
            keyboardType="phone-pad"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>URL de Foto</Text>
          <TextInput
            style={styles.input}
            value={foto}
            onChangeText={setFoto}
            placeholder="https://ejemplo.com/foto.jpg"
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Departamento *</Text>
          {departamentoViewModel.isLoading ? (
            <ActivityIndicator />
          ) : (
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={idDepartamento}
                onValueChange={(value) => setIdDepartamento(value)}
                style={styles.picker}
              >
                <Picker.Item label="Seleccione un departamento" value={0} />
                {departamentoViewModel.departamentos.map((dept) => (
                  <Picker.Item key={dept.id} label={dept.nombre} value={dept.id} />
                ))}
              </Picker>
            </View>
          )}
        </View>

        <TouchableOpacity 
          style={styles.saveButton}
          onPress={handleGuardar}
          disabled={personaViewModel.isLoading}
        >
          {personaViewModel.isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.saveButtonText}>
              {isEditing ? '💾 Actualizar' : '➕ Crear'}
            </Text>
          )}
        </TouchableOpacity>

        <View style={styles.spacer} />
      </ScrollView>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    fontSize: 16,
    color: '#fff',
    marginRight: 15,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  previewImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignSelf: 'center',
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  pickerContainer: {
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  picker: {
    height: 50,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  spacer: {
    height: 40,
  },
});
