import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { observer } from 'mobx-react-lite';
import { useViewModels } from '../context/ViewModelsContext';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Departamento } from '../../domain/entities/Departamento';

export const EditarInsertarDepartamentoView: React.FC = observer(() => {
  const { departamentoViewModel } = useViewModels();
  const navigation = useNavigation();
  const route = useRoute<any>();
  
  const departamentoId = route.params?.departamentoId;
  const isEditing = !!departamentoId;

  const [nombre, setNombre] = useState('');

  useEffect(() => {
    if (isEditing) {
      cargarDatosDepartamento();
    }
  }, []);

  const cargarDatosDepartamento = async () => {
    await departamentoViewModel.cargarDepartamentoPorId(departamentoId);
    const departamento = departamentoViewModel.departamentoSeleccionado;
    
    if (departamento) {
      setNombre(departamento.nombre);
    }
  };

  const validarCampos = (): boolean => {
    if (!nombre.trim()) {
      Alert.alert('Error', 'El nombre es obligatorio');
      return false;
    }
    return true;
  };

  const handleGuardar = async () => {
    if (!validarCampos()) return;

    const departamento = new Departamento(
      isEditing ? departamentoId : 0,
      nombre
    );

    try {
      if (isEditing) {
        await departamentoViewModel.actualizarDepartamento(departamento);
        Alert.alert('Éxito', 'Departamento actualizado correctamente');
      } else {
        await departamentoViewModel.crearDepartamento(departamento);
        Alert.alert('Éxito', 'Departamento creado correctamente');
      }
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', departamentoViewModel.error || 'No se pudo guardar el departamento');
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backButton}>← Volver</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {isEditing ? 'Editar Departamento' : 'Nuevo Departamento'}
        </Text>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>📁</Text>
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Nombre del Departamento *</Text>
          <TextInput
            style={styles.input}
            value={nombre}
            onChangeText={setNombre}
            placeholder="Ingrese el nombre del departamento"
          />
        </View>

        <TouchableOpacity 
          style={styles.saveButton}
          onPress={handleGuardar}
          disabled={departamentoViewModel.isLoading}
        >
          {departamentoViewModel.isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.saveButtonText}>
              {isEditing ? '💾 Actualizar' : '➕ Crear'}
            </Text>
          )}
        </TouchableOpacity>

        <View style={styles.infoContainer}>
          <Text style={styles.infoText}>
            {isEditing 
              ? 'Los cambios se aplicarán inmediatamente al departamento.'
              : 'El departamento estará disponible para asignar a personas una vez creado.'}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#2196F3',
    padding: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    fontSize: 16,
    color: '#fff',
    marginRight: 15,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  iconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: 30,
  },
  icon: {
    fontSize: 50,
  },
  formGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  infoContainer: {
    backgroundColor: '#E3F2FD',
    padding: 15,
    borderRadius: 8,
    marginTop: 20,
  },
  infoText: {
    color: '#1976D2',
    fontSize: 14,
    textAlign: 'center',
  },
});
