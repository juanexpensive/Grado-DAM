import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { BienvenidaView } from '../views/BienvenidaView';
import { ListadoPersonasView } from '../views/ListadoPersonasView';
import { EditarInsertarPersonasView } from '../views/EditarInsertarPersonasView';
import { ListadoDepartamentosView } from '../views/ListadoDepartamentosView';
import { EditarInsertarDepartamentoView } from '../views/EditarInsertarDepartamentoView';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

const PersonasStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="ListadoPersonas" component={ListadoPersonasView} />
    <Stack.Screen name="EditarInsertarPersonas" component={EditarInsertarPersonasView} />
  </Stack.Navigator>
);

const DepartamentosStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="ListadoDepartamentos" component={ListadoDepartamentosView} />
    <Stack.Screen name="EditarInsertarDepartamento" component={EditarInsertarDepartamentoView} />
  </Stack.Navigator>
);

export const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        initialRouteName="Bienvenida"
        screenOptions={{
          headerShown: false,
          drawerStyle: {
            backgroundColor: '#f5f5f5',
            width: 280,
          },
          drawerActiveTintColor: '#2196F3',
          drawerInactiveTintColor: '#666',
          drawerLabelStyle: {
            fontSize: 16,
            fontWeight: 'bold',
          },
        }}
      >
        <Drawer.Screen 
          name="Bienvenida" 
          component={BienvenidaView}
          options={{
            drawerLabel: '🏠 Inicio',
          }}
        />
        <Drawer.Screen 
          name="Personas" 
          component={PersonasStack}
          options={{
            drawerLabel: '👥 Personas',
          }}
        />
        <Drawer.Screen 
          name="Departamentos" 
          component={DepartamentosStack}
          options={{
            drawerLabel: '📁 Departamentos',
          }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};
