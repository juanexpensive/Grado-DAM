import { makeAutoObservable, runInAction } from 'mobx';
import { IUseCasePersonas } from '../../domain/interfaces/use-cases/IUseCasePersonas';
import { PersonaConNombreDeDepartamentoDTO } from '../../domain/dtos/PersonaConNombreDeDepartamentoDTO';
import { Persona } from '../../domain/entities/Persona';

export class PersonaViewModel {
  personas: PersonaConNombreDeDepartamentoDTO[] = [];
  personasFiltradas: PersonaConNombreDeDepartamentoDTO[] = [];
  personaSeleccionada: Persona | null = null;
  isLoading: boolean = false;
  error: string | null = null;
  searchQuery: string = '';

  constructor(private useCasePersonas: IUseCasePersonas) {
    makeAutoObservable(this);
  }

  async cargarPersonas() {
    this.isLoading = true;
    this.error = null;
    
    try {
      const personas = await this.useCasePersonas.getListaPersonasConDepartamento();
      runInAction(() => {
        this.personas = personas;
        this.personasFiltradas = personas;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al cargar personas';
        this.isLoading = false;
      });
    }
  }

  async cargarPersonaPorId(id: number) {
    this.isLoading = true;
    this.error = null;
    
    try {
      // Obtener lista completa de personas (entidades, no DTOs)
      const personas = await this.useCasePersonas.getListaPersonas();
      const persona = personas.find(p => p.id === id);
      
      runInAction(() => {
        this.personaSeleccionada = persona || null;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al cargar persona';
        this.isLoading = false;
      });
    }
  }

  buscarPersonas(query: string) {
    this.searchQuery = query;
    
    if (query.trim() === '') {
      this.personasFiltradas = this.personas;
    } else {
      const queryLower = query.toLowerCase();
      this.personasFiltradas = this.personas.filter(persona =>
        persona.nombre.toLowerCase().includes(queryLower) ||
        persona.apellidos.toLowerCase().includes(queryLower) ||
        persona.nombreDepartamento.toLowerCase().includes(queryLower)
      );
    }
  }

  async crearPersona(persona: Persona) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCasePersonas.crearPersona(persona);
      await this.cargarPersonas();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al crear persona';
        this.isLoading = false;
      });
      throw error;
    }
  }

  async actualizarPersona(id: number, persona: Persona) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCasePersonas.actualizarPersona(id, persona);
      await this.cargarPersonas();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al actualizar persona';
        this.isLoading = false;
      });
      throw error;
    }
  }

  async eliminarPersona(id: number) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCasePersonas.eliminarPersona(id);
      await this.cargarPersonas();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al eliminar persona';
        this.isLoading = false;
      });
      throw error;
    }
  }

  limpiarPersonaSeleccionada() {
    this.personaSeleccionada = null;
  }

  limpiarError() {
    this.error = null;
  }
}
