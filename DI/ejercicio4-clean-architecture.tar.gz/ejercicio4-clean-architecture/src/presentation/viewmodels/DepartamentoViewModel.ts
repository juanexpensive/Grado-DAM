import { makeAutoObservable, runInAction } from 'mobx';
import { IUseCaseDepartamentos } from '../../domain/interfaces/use-cases/IUseCaseDepartamentos';
import { Departamento } from '../../domain/entities/Departamento';

export class DepartamentoViewModel {
  departamentos: Departamento[] = [];
  departamentosFiltrados: Departamento[] = [];
  departamentoSeleccionado: Departamento | null = null;
  isLoading: boolean = false;
  error: string | null = null;
  searchQuery: string = '';

  constructor(private useCaseDepartamentos: IUseCaseDepartamentos) {
    makeAutoObservable(this);
  }

  async cargarDepartamentos() {
    this.isLoading = true;
    this.error = null;
    
    try {
      const departamentos = await this.useCaseDepartamentos.getDepartamentos();
      runInAction(() => {
        this.departamentos = departamentos;
        this.departamentosFiltrados = departamentos;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al cargar departamentos';
        this.isLoading = false;
      });
    }
  }

  async cargarDepartamentoPorId(id: number) {
    this.isLoading = true;
    this.error = null;
    
    try {
      const departamento = await this.useCaseDepartamentos.getDetalleDepartamento(id);
      runInAction(() => {
        this.departamentoSeleccionado = departamento;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al cargar departamento';
        this.isLoading = false;
      });
    }
  }

  buscarDepartamentos(query: string) {
    this.searchQuery = query;
    
    if (query.trim() === '') {
      this.departamentosFiltrados = this.departamentos;
    } else {
      const queryLower = query.toLowerCase();
      this.departamentosFiltrados = this.departamentos.filter(departamento =>
        departamento.nombre.toLowerCase().includes(queryLower)
      );
    }
  }

  async crearDepartamento(departamento: Departamento) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCaseDepartamentos.crearDepartamento(departamento);
      await this.cargarDepartamentos();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al crear departamento';
        this.isLoading = false;
      });
      throw error;
    }
  }

  async actualizarDepartamento(departamento: Departamento) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCaseDepartamentos.actualizarDepartamento(departamento);
      await this.cargarDepartamentos();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al actualizar departamento';
        this.isLoading = false;
      });
      throw error;
    }
  }

  async eliminarDepartamento(id: number) {
    this.isLoading = true;
    this.error = null;
    
    try {
      await this.useCaseDepartamentos.eliminarDepartamento(id);
      await this.cargarDepartamentos();
    } catch (error) {
      runInAction(() => {
        this.error = error instanceof Error ? error.message : 'Error al eliminar departamento';
        this.isLoading = false;
      });
      throw error;
    }
  }

  limpiarDepartamentoSeleccionado() {
    this.departamentoSeleccionado = null;
  }

  limpiarError() {
    this.error = null;
  }
}
