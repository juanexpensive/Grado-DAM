import React, { createContext, useContext } from 'react';
import { container } from '../../core/container';
import { TYPES } from '../../core/types';
import { PersonaViewModel } from '../viewmodels/PersonaViewModel';
import { DepartamentoViewModel } from '../viewmodels/DepartamentoViewModel';
import { IUseCasePersonas } from '../../domain/interfaces/use-cases/IUseCasePersonas';
import { IUseCaseDepartamentos } from '../../domain/interfaces/use-cases/IUseCaseDepartamentos';

interface ViewModelsContextType {
  personaViewModel: PersonaViewModel;
  departamentoViewModel: DepartamentoViewModel;
}

const ViewModelsContext = createContext<ViewModelsContextType | null>(null);

export const ViewModelsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const useCasePersonas = container.get<IUseCasePersonas>(TYPES.IUseCasePersonas);
  const useCaseDepartamentos = container.get<IUseCaseDepartamentos>(TYPES.IUseCaseDepartamentos);

  const personaViewModel = new PersonaViewModel(useCasePersonas);
  const departamentoViewModel = new DepartamentoViewModel(useCaseDepartamentos);

  return (
    <ViewModelsContext.Provider value={{ personaViewModel, departamentoViewModel }}>
      {children}
    </ViewModelsContext.Provider>
  );
};

export const useViewModels = () => {
  const context = useContext(ViewModelsContext);
  if (!context) {
    throw new Error('useViewModels debe ser usado dentro de ViewModelsProvider');
  }
  return context;
};
