# Ejercicio 4 - Clean Architecture en React Native

## 📋 Resumen del Proyecto

Aplicación móvil para gestión de Personas y Departamentos que implementa **Clean Architecture**, **MVVM**, **Inyección de Dependencias** y **Programación Reactiva**.

### ✨ Características Principales

- ✅ CRUD completo de Personas y Departamentos
- ✅ Navegación con Drawer
- ✅ Búsqueda en tiempo real
- ✅ Reglas de negocio implementadas
- ✅ Arquitectura limpia y escalable
- ✅ Código testeable y mantenible

## 🏗️ Arquitectura Implementada

```
┌─────────────────────────────────────────┐
│         PRESENTATION LAYER              │
│  (Views + ViewModels + Navigation)      │
│         React Native + MobX             │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│          DOMAIN LAYER                   │
│  (Entities + DTOs + Use Cases)          │
│      Pure TypeScript - No Frameworks    │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│           DATA LAYER                    │
│    (Repositories + API Integration)     │
│          Fetch API + Mappers            │
└─────────────────────────────────────────┘
```

## 🎯 Patrones de Diseño Aplicados

### 1. Clean Architecture
- Separación en capas con dependencias unidireccionales
- Domain independiente de frameworks
- Reglas de negocio en Use Cases

### 2. MVVM (Model-View-ViewModel)
- **Model**: Entidades y DTOs del dominio
- **ViewModel**: Lógica de presentación con MobX
- **View**: Componentes React observadores

### 3. Repository Pattern
- Abstracción del acceso a datos
- Implementaciones intercambiables
- Fácil testing con mocks

### 4. Dependency Injection (Inversify)
- Inversión de control
- Configuración centralizada
- Testing simplificado

### 5. Observer Pattern (MobX)
- Estado reactivo
- Actualizaciones automáticas de UI
- Código declarativo

## 📁 Estructura del Proyecto

```
ejercicio4-clean-architecture/
│
├── src/
│   ├── core/                          # Configuración DI
│   │   ├── container.ts              # Contenedor Inversify
│   │   └── types.ts                  # Símbolos DI
│   │
│   ├── domain/                        # Capa de Dominio
│   │   ├── entities/                 # Persona, Departamento
│   │   ├── dtos/                     # PersonaConNombreDeDepartamentoDTO
│   │   ├── interfaces/               # Contratos
│   │   │   ├── repositories/        # IRepository*
│   │   │   └── use-cases/           # IUseCase*
│   │   └── use-cases/                # Implementaciones + Reglas de Negocio
│   │
│   ├── data/                          # Capa de Datos
│   │   ├── db/                       # Configuración API
│   │   └── repositories/             # *RepositoryAPI
│   │
│   └── presentation/                  # Capa de Presentación
│       ├── context/                  # Context de ViewModels
│       ├── viewmodels/               # ViewModels con MobX
│       ├── views/                    # Componentes React
│       └── navigation/               # Navegación Drawer + Stack
│
├── App.tsx                            # Punto de entrada
├── package.json                       # Dependencias
├── tsconfig.json                      # Configuración TypeScript
├── babel.config.js                    # Configuración Babel
└── README.md                          # Documentación
```

## 🎨 Vistas de la Aplicación

### 1. Bienvenida
- Pantalla de inicio
- Información de la app
- Acceso al menú

### 2. Listado de Personas
- Tarjetas con foto y datos
- Búsqueda en tiempo real
- Botones de acción (Editar/Eliminar)
- FAB para crear

### 3. Editar/Insertar Persona
- Formulario completo
- Validaciones
- Selector de departamento
- Preview de foto

### 4. Listado de Departamentos
- Lista de departamentos
- Búsqueda
- Acciones CRUD

### 5. Editar/Insertar Departamento
- Formulario simple
- Validaciones

## ⚙️ Reglas de Negocio

### Regla 1: Filtrado por Edad (Viernes y Sábado)
```typescript
// Los viernes y sábados solo se muestran personas > 18 años
if (diaSemana === 5 || diaSemana === 6) {
  return personas.filter(p => calcularEdad(p.fechaNacimiento) > 18);
}
```

### Regla 2: Restricción de Eliminación (Domingo)
```typescript
// No se puede eliminar personas los domingos
if (diaSemana === 0) {
  throw new Error('No está permitido eliminar personas los domingos');
}
```

## 🔧 Tecnologías Utilizadas

| Tecnología | Propósito |
|------------|-----------|
| React Native + Expo | Framework móvil |
| TypeScript | Tipado estático |
| Inversify | Inyección de dependencias |
| MobX | Estado reactivo |
| React Navigation | Navegación |
| Fetch API | Peticiones HTTP |

## 📊 Mapeo de Datos API ↔ Aplicación

### API → Aplicación

| API (camelCase) | Aplicación | Tipo |
|-----------------|------------|------|
| `apellido` | `apellidos` | string |
| `fechaNac` | `fechaNacimiento` | string |
| `imagen` | `foto` | string |

### Entidades vs DTOs

**Persona (Entidad)**
- Se usa para crear/editar
- Tiene `idDepartamento` (número)
- Se guarda en BD

**PersonaConNombreDeDepartamentoDTO**
- Solo para visualización
- Tiene `nombreDepartamento` (string)
- NO se guarda en BD

## 🚀 Instalación y Uso

### 1. Instalar Dependencias
```bash
npm install
```

### 2. Configurar API
Editar `src/data/db/config.ts`:
```typescript
export const API_CONFIG = {
  BASE_URL: 'https://tu-api-azure.azurewebsites.net/api',
  // ...
};
```

### 3. Ejecutar
```bash
npm start
```

## ✅ Checklist de Implementación

### Clean Architecture
- [x] Separación en capas (Presentation, Domain, Data)
- [x] Dependencias unidireccionales
- [x] Domain independiente de frameworks
- [x] Interfaces para abstracciones

### MVVM
- [x] ViewModels con lógica de presentación
- [x] Views como componentes observadores
- [x] Separación clara de responsabilidades

### Inyección de Dependencias
- [x] Container de Inversify configurado
- [x] Interfaces inyectadas en constructores
- [x] Símbolos para tipos
- [x] Decoradores @injectable y @inject

### MobX
- [x] Observables en ViewModels
- [x] Componentes observer
- [x] makeAutoObservable
- [x] runInAction para actualizaciones

### CRUD
- [x] Crear Persona/Departamento
- [x] Leer/Listar Persona/Departamento
- [x] Actualizar Persona/Departamento
- [x] Eliminar Persona/Departamento

### UI/UX
- [x] Drawer Navigation
- [x] Búsqueda en tiempo real
- [x] Validaciones de formulario
- [x] Confirmaciones de eliminación
- [x] Loading indicators
- [x] Manejo de errores

### Reglas de Negocio
- [x] Filtrado por edad (viernes/sábado)
- [x] Restricción eliminación (domingo)

## 📚 Documentación Adicional

- **README.md**: Documentación general
- **ARQUITECTURA.md**: Detalles de arquitectura y patrones
- **CONFIGURACION.md**: Guía de configuración y troubleshooting

## 🎓 Conceptos Aprendidos

1. **Clean Architecture** - Arquitectura en capas
2. **MVVM** - Patrón de presentación
3. **Dependency Injection** - Inversión de control
4. **Repository Pattern** - Abstracción de datos
5. **Observer Pattern** - Programación reactiva
6. **TypeScript** - Tipado fuerte
7. **React Navigation** - Navegación móvil
8. **MobX** - Estado global reactivo

## 🏆 Ventajas de esta Arquitectura

### Testeable
- Use Cases testeables sin UI
- Repositories mockeables
- ViewModels aislados

### Mantenible
- Código organizado en capas
- Responsabilidades claras
- Fácil de entender

### Escalable
- Agregar features sin romper código
- Cambiar implementaciones fácilmente
- Reutilización de código

### Flexible
- Cambiar de API REST a GraphQL
- Cambiar de MobX a Redux
- Cambiar UI sin afectar lógica

## 🔮 Posibles Extensiones

- [ ] Tests unitarios con Jest
- [ ] Tests de integración
- [ ] Caché con AsyncStorage
- [ ] Modo offline
- [ ] Sincronización automática
- [ ] Autenticación y autorización
- [ ] Subida de imágenes a Azure Storage
- [ ] Paginación en listados
- [ ] Filtros avanzados
- [ ] Exportar a PDF/Excel

## 👨‍💻 Autor

Desarrollado como ejercicio de aprendizaje de Clean Architecture, MVVM y patrones de diseño en React Native.

---

**Nota**: Este proyecto es un ejemplo educativo que demuestra la aplicación práctica de principios SOLID y arquitectura limpia en una aplicación móvil real.
