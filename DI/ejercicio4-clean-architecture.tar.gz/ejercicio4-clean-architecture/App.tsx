import 'reflect-metadata';
import React from 'react';
import { ViewModelsProvider } from './src/presentation/context/ViewModelsContext';
import { AppNavigator } from './src/presentation/navigation/AppNavigator';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ViewModelsProvider>
        <AppNavigator />
      </ViewModelsProvider>
    </GestureHandlerRootView>
  );
}
